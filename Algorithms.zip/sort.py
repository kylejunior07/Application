dataset = [
    {"name": "Alexa", "class": "HB04", "exam score": 82, "project score": 74},
    {"name": "Luis", "class": "HB05", "exam score": 68, "project score": 79},
    {"name": "Samir", "class": "HB04", "exam score": 90, "project score": 88},
    {"name": "Jaden", "class": "HB05", "exam score": 77, "project score": 85},
    {"name": "Elena", "class": "HB04", "exam score": 95, "project score": 91},
    {"name": "Marco", "class": "HB05", "exam score": 88, "project score": 80}
]

# Define a function to sort a list of students by their project score in descending order.
def sort_by_project_score(dataset):
    n = len(dataset)
    # Perform a bubble sort on the list.
    for i in range(n):
        for j in range(0, n-i-1):
            # Compare adjacent scores and swap if in wrong order.
            if dataset[j]['project score'] < dataset[j+1]['project score']:
                dataset[j], dataset[j+1] = dataset[j+1], dataset[j]
    # Return the sorted list.
    return dataset

# Sort the dataset by project score using the defined function.
sorted_dataset = sort_by_project_score(dataset)
# Print the sorted list.
print(sorted_dataset)
