dataset = [
  { "name": "Alexa", "class": "HB04", "exam score": 82, "project score": 74 },
  { "name": "Luis",  "class": "HB05", "exam score": 68, "project score": 79 },
  { "name": "Samir", "class": "HB04", "exam score": 90, "project score": 88 },
  { "name": "Jaden", "class": "HB05", "exam score": 77, "project score": 85 },
  { "name": "Elena", "class": "HB04", "exam score": 95, "project score": 91 },
  { "name": "Marco", "class": "HB05", "exam score": 88, "project score": 80 }
]



def organize_students_by_class(dataset):
    # Initialize an empty dictionary to take in data.
    organized_data = {}
    for student in dataset:
        # Extract the class name from the current student.
        class_name = student["class"]

        if class_name not in organized_data:
            organized_data[class_name] = []
        organized_data[class_name].append(student)
    # Return the organized data.
    return organized_data

    # Organize the dataset by class and get the names in lists.
    organized_names = organize_students_names_by_class(dataset)
    organized_names

# Function to print all students, organized by class.
def print_students_by_class(organized_data):
    for class_name, students in organized_data.items():
        print(f"Student in Class {class_name}:")
        # Print details of each student in the current class.
        for student in students:
            print(f"Name: {student['name']}, Class: {student['class']}\n")

# Function to calculate average scores for each class.
def calculate_average_scores(dataset):
    # Initialize dictionaries to hold total scores and counts of students per class.
    class_scores = {}
    class_counts = {}

    for student in dataset:
        # Extract the class name and exam score from the current student.
        class_name = student["class"]
        score = student["exam score"]
        # Update the total score and count for the current class.
        class_scores[class_name] = class_scores.get(class_name, 0) + score
        class_counts[class_name] = class_counts.get(class_name, 0) + 1

    # Calculate the average score for each class and return it as a dictionary.
    return {class_name: class_scores[class_name] / class_counts[class_name] for class_name in class_scores}

# Function to print the average exam scores for each class.
def print_average_scores(average_scores):
    for class_name, avg_score in average_scores.items():
        # Print the class name and its formatted average score.
        print(f"Average Exam Score for Class {class_name}: {avg_score:.2f}")


# Organize the dataset by class.
organized_data = organize_students_by_class(dataset)
# Print the organized students by class.
print_students_by_class(organized_data)

# Calculate the average scores for each class.
average_scores = calculate_average_scores(dataset)
# Print the average scores for each class.
print_average_scores(average_scores)
