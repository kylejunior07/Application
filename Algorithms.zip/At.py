dataset = [
  { "name": "Alexa", "class": "HB04", "exam score": 82, "project score": 74 },
  { "name": "Luis",  "class": "HB05", "exam score": 68, "project score": 79 },
  { "name": "Samir", "class": "HB04", "exam score": 90, "project score": 88 },
  { "name": "Jaden", "class": "HB05", "exam score": 77, "project score": 85 },
  { "name": "Elena", "class": "HB04", "exam score": 95, "project score": 91 },
  { "name": "Marco", "class": "HB05", "exam score": 88, "project score": 80 }
]


# Function to filter students by a given class and print their details.
def filter_students_by_class(class_to_filter, dataset):
    filtered_students = [student for student in dataset if student['class'] == class_to_filter]
    
    if filtered_students:
        print(f"Students from {class_to_filter}:")
        # Loop through each student in the filtered list and print their details.
        for student in filtered_students:
            print(f"Name: {student['name']}, Class: {student['class']}, Exam Score: {student['exam score']}")
    else:
        # If the filtered list is empty, print that no students were found.
        print(f"No students found from {class_to_filter}.")

# Ask the user to enter the class they want to filter by.
UserInput = input("Enter the class to filter by: ")
# Call the function with the user input and the dataset to filter and print the students.
filter_students_by_class(UserInput, dataset)
